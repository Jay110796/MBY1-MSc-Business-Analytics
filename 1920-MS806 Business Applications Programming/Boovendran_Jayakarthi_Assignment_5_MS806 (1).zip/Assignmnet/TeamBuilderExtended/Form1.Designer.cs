﻿using System.Windows.Forms;
using System.Drawing;
namespace TeamBuilderExtended
{
    partial class TeamBuilderV2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TeamBuilderV2));
            this.HomePageGroupBox = new System.Windows.Forms.GroupBox();
            this.RunningTotalGroupBox = new System.Windows.Forms.GroupBox();
            this.RunningTotalLabel = new System.Windows.Forms.Label();
            this.RunningTotalTextBox = new System.Windows.Forms.TextBox();
            this.GenerateManagementReport = new System.Windows.Forms.Button();
            this.ResetButton = new System.Windows.Forms.Button();
            this.Exit = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Note2Label = new System.Windows.Forms.Label();
            this.AddToBookingButton = new System.Windows.Forms.Button();
            this.ConfirmOrderButton = new System.Windows.Forms.Button();
            this.BookingInfoLabel = new System.Windows.Forms.Label();
            this.BookingInfoGridView = new System.Windows.Forms.DataGridView();
            this.ClearButton = new System.Windows.Forms.Button();
            this.MealPlanGridView = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            this.LocationInfoGridView = new System.Windows.Forms.DataGridView();
            this.EventLocationLabel = new System.Windows.Forms.Label();
            this.EventsLabel = new System.Windows.Forms.Label();
            this.EventInfoGridView = new System.Windows.Forms.DataGridView();
            this.ManagementReportTooltip = new System.Windows.Forms.ToolTip(this.components);
            this.SaveToolTip = new System.Windows.Forms.ToolTip(this.components);
            this.ClearSelectionTooltip = new System.Windows.Forms.ToolTip(this.components);
            this.CompleteOrderTooltip = new System.Windows.Forms.ToolTip(this.components);
            this.AddToBookingTooltip = new System.Windows.Forms.ToolTip(this.components);
            this.ResetTooltip = new System.Windows.Forms.ToolTip(this.components);
            this.HomePageGroupBox.SuspendLayout();
            this.RunningTotalGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BookingInfoGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MealPlanGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LocationInfoGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.EventInfoGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // HomePageGroupBox
            // 
            this.HomePageGroupBox.BackColor = System.Drawing.Color.Honeydew;
            this.HomePageGroupBox.Controls.Add(this.RunningTotalGroupBox);
            this.HomePageGroupBox.Controls.Add(this.GenerateManagementReport);
            this.HomePageGroupBox.Controls.Add(this.ResetButton);
            this.HomePageGroupBox.Controls.Add(this.Exit);
            this.HomePageGroupBox.Controls.Add(this.pictureBox1);
            this.HomePageGroupBox.Controls.Add(this.Note2Label);
            this.HomePageGroupBox.Controls.Add(this.AddToBookingButton);
            this.HomePageGroupBox.Controls.Add(this.ConfirmOrderButton);
            this.HomePageGroupBox.Controls.Add(this.BookingInfoLabel);
            this.HomePageGroupBox.Controls.Add(this.BookingInfoGridView);
            this.HomePageGroupBox.Controls.Add(this.ClearButton);
            this.HomePageGroupBox.Controls.Add(this.MealPlanGridView);
            this.HomePageGroupBox.Controls.Add(this.label2);
            this.HomePageGroupBox.Controls.Add(this.LocationInfoGridView);
            this.HomePageGroupBox.Controls.Add(this.EventLocationLabel);
            this.HomePageGroupBox.Controls.Add(this.EventsLabel);
            this.HomePageGroupBox.Controls.Add(this.EventInfoGridView);
            this.HomePageGroupBox.Location = new System.Drawing.Point(12, 13);
            this.HomePageGroupBox.Name = "HomePageGroupBox";
            this.HomePageGroupBox.Size = new System.Drawing.Size(1327, 718);
            this.HomePageGroupBox.TabIndex = 0;
            this.HomePageGroupBox.TabStop = false;
            // 
            // RunningTotalGroupBox
            // 
            this.RunningTotalGroupBox.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.RunningTotalGroupBox.Controls.Add(this.RunningTotalLabel);
            this.RunningTotalGroupBox.Controls.Add(this.RunningTotalTextBox);
            this.RunningTotalGroupBox.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.RunningTotalGroupBox.Location = new System.Drawing.Point(489, 383);
            this.RunningTotalGroupBox.Name = "RunningTotalGroupBox";
            this.RunningTotalGroupBox.Size = new System.Drawing.Size(265, 151);
            this.RunningTotalGroupBox.TabIndex = 21;
            this.RunningTotalGroupBox.TabStop = false;
            // 
            // RunningTotalLabel
            // 
            this.RunningTotalLabel.AutoSize = true;
            this.RunningTotalLabel.Font = new System.Drawing.Font("Times New Roman", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RunningTotalLabel.Location = new System.Drawing.Point(41, 43);
            this.RunningTotalLabel.Name = "RunningTotalLabel";
            this.RunningTotalLabel.Size = new System.Drawing.Size(188, 19);
            this.RunningTotalLabel.TabIndex = 1;
            this.RunningTotalLabel.Text = "Running Total of Orders";
            // 
            // RunningTotalTextBox
            // 
            this.RunningTotalTextBox.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RunningTotalTextBox.Location = new System.Drawing.Point(45, 90);
            this.RunningTotalTextBox.Name = "RunningTotalTextBox";
            this.RunningTotalTextBox.ReadOnly = true;
            this.RunningTotalTextBox.Size = new System.Drawing.Size(184, 27);
            this.RunningTotalTextBox.TabIndex = 0;
            this.RunningTotalTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // GenerateManagementReport
            // 
            this.GenerateManagementReport.BackColor = System.Drawing.Color.PaleGreen;
            this.GenerateManagementReport.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.GenerateManagementReport.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GenerateManagementReport.Location = new System.Drawing.Point(767, 600);
            this.GenerateManagementReport.Name = "GenerateManagementReport";
            this.GenerateManagementReport.Size = new System.Drawing.Size(255, 38);
            this.GenerateManagementReport.TabIndex = 20;
            this.GenerateManagementReport.Text = "Generate &Management Report";
            this.ManagementReportTooltip.SetToolTip(this.GenerateManagementReport, "Click to Generate Management Report");
            this.GenerateManagementReport.UseVisualStyleBackColor = false;
            this.GenerateManagementReport.Click += new System.EventHandler(this.GenerateManagementReport_Click);
            // 
            // ResetButton
            // 
            this.ResetButton.BackColor = System.Drawing.Color.PaleGreen;
            this.ResetButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ResetButton.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ResetButton.Location = new System.Drawing.Point(489, 600);
            this.ResetButton.Name = "ResetButton";
            this.ResetButton.Size = new System.Drawing.Size(169, 38);
            this.ResetButton.TabIndex = 19;
            this.ResetButton.Text = "Re&set Form";
            this.ResetTooltip.SetToolTip(this.ResetButton, "Click to Reset Form");
            this.ResetButton.UseVisualStyleBackColor = false;
            this.ResetButton.Click += new System.EventHandler(this.ResetButton_Click);
            // 
            // Exit
            // 
            this.Exit.BackColor = System.Drawing.Color.PaleGreen;
            this.Exit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Exit.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Exit.Location = new System.Drawing.Point(1111, 600);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(169, 38);
            this.Exit.TabIndex = 18;
            this.Exit.Text = "Save and E&xit";
            this.SaveToolTip.SetToolTip(this.Exit, "Click to Save and Exit!");
            this.Exit.UseVisualStyleBackColor = false;
            this.Exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Image = global::TeamBuilderExtended.Properties.Resources.Logo;
            this.pictureBox1.Location = new System.Drawing.Point(26, 348);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(444, 290);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox1.TabIndex = 17;
            this.pictureBox1.TabStop = false;
            // 
            // Note2Label
            // 
            this.Note2Label.AutoSize = true;
            this.Note2Label.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Note2Label.Location = new System.Drawing.Point(622, 247);
            this.Note2Label.Name = "Note2Label";
            this.Note2Label.Size = new System.Drawing.Size(304, 19);
            this.Note2Label.TabIndex = 14;
            this.Note2Label.Text = "Note : Enter in values for No. of Bookings";
            // 
            // AddToBookingButton
            // 
            this.AddToBookingButton.BackColor = System.Drawing.Color.LightGreen;
            this.AddToBookingButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.AddToBookingButton.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddToBookingButton.Location = new System.Drawing.Point(1111, 383);
            this.AddToBookingButton.Name = "AddToBookingButton";
            this.AddToBookingButton.Size = new System.Drawing.Size(169, 38);
            this.AddToBookingButton.TabIndex = 13;
            this.AddToBookingButton.Text = "Add to &Booking";
            this.AddToBookingTooltip.SetToolTip(this.AddToBookingButton, "Click to Add Booking to Order");
            this.AddToBookingButton.UseVisualStyleBackColor = false;
            this.AddToBookingButton.Click += new System.EventHandler(this.AddToBookingButton_Click);
            // 
            // ConfirmOrderButton
            // 
            this.ConfirmOrderButton.BackColor = System.Drawing.Color.LightGreen;
            this.ConfirmOrderButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ConfirmOrderButton.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ConfirmOrderButton.Location = new System.Drawing.Point(1111, 483);
            this.ConfirmOrderButton.Name = "ConfirmOrderButton";
            this.ConfirmOrderButton.Size = new System.Drawing.Size(169, 38);
            this.ConfirmOrderButton.TabIndex = 11;
            this.ConfirmOrderButton.Text = "Complete &Order";
            this.CompleteOrderTooltip.SetToolTip(this.ConfirmOrderButton, "Click to Complete Order");
            this.ConfirmOrderButton.UseVisualStyleBackColor = false;
            this.ConfirmOrderButton.Click += new System.EventHandler(this.ConfirmOrderButton_Click);
            // 
            // BookingInfoLabel
            // 
            this.BookingInfoLabel.AutoSize = true;
            this.BookingInfoLabel.Font = new System.Drawing.Font("Times New Roman", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BookingInfoLabel.Location = new System.Drawing.Point(485, 247);
            this.BookingInfoLabel.Name = "BookingInfoLabel";
            this.BookingInfoLabel.Size = new System.Drawing.Size(105, 19);
            this.BookingInfoLabel.TabIndex = 10;
            this.BookingInfoLabel.Text = "Booking Info";
            // 
            // BookingInfoGridView
            // 
            this.BookingInfoGridView.AllowUserToAddRows = false;
            this.BookingInfoGridView.AllowUserToDeleteRows = false;
            this.BookingInfoGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.BookingInfoGridView.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BookingInfoGridView.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.DarkSeaGreen;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.DarkSeaGreen;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.BookingInfoGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.BookingInfoGridView.ColumnHeadersHeight = 29;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.PaleGreen;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.BookingInfoGridView.DefaultCellStyle = dataGridViewCellStyle2;
            this.BookingInfoGridView.EnableHeadersVisualStyles = false;
            this.BookingInfoGridView.GridColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BookingInfoGridView.Location = new System.Drawing.Point(489, 287);
            this.BookingInfoGridView.Name = "BookingInfoGridView";
            this.BookingInfoGridView.RowHeadersWidth = 51;
            this.BookingInfoGridView.RowTemplate.Height = 24;
            this.BookingInfoGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.BookingInfoGridView.Size = new System.Drawing.Size(791, 53);
            this.BookingInfoGridView.TabIndex = 9;
            this.BookingInfoGridView.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.BookingInfoGridView_CellLeave);
            this.BookingInfoGridView.CellLeave += new System.Windows.Forms.DataGridViewCellEventHandler(this.BookingInfoGridView_CellLeave);
            // 
            // ClearButton
            // 
            this.ClearButton.BackColor = System.Drawing.Color.LightGreen;
            this.ClearButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ClearButton.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ClearButton.Location = new System.Drawing.Point(1111, 193);
            this.ClearButton.Name = "ClearButton";
            this.ClearButton.Size = new System.Drawing.Size(169, 38);
            this.ClearButton.TabIndex = 7;
            this.ClearButton.Text = "&Clear Selection";
            this.ClearSelectionTooltip.SetToolTip(this.ClearButton, "Click to Clear Selected Event, Location and Meal Plan");
            this.ClearButton.UseVisualStyleBackColor = false;
            this.ClearButton.Click += new System.EventHandler(this.ClearButton_Click);
            // 
            // MealPlanGridView
            // 
            this.MealPlanGridView.AllowUserToAddRows = false;
            this.MealPlanGridView.AllowUserToDeleteRows = false;
            this.MealPlanGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.MealPlanGridView.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.MealPlanGridView.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.MealPlanGridView.CausesValidation = false;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.DarkSeaGreen;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.DarkSeaGreen;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.MealPlanGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.MealPlanGridView.ColumnHeadersHeight = 29;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.PaleGreen;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.MealPlanGridView.DefaultCellStyle = dataGridViewCellStyle4;
            this.MealPlanGridView.EnableHeadersVisualStyles = false;
            this.MealPlanGridView.GridColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.MealPlanGridView.Location = new System.Drawing.Point(1025, 54);
            this.MealPlanGridView.MultiSelect = false;
            this.MealPlanGridView.Name = "MealPlanGridView";
            this.MealPlanGridView.ReadOnly = true;
            this.MealPlanGridView.RowHeadersWidth = 51;
            this.MealPlanGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.MealPlanGridView.Size = new System.Drawing.Size(255, 119);
            this.MealPlanGridView.TabIndex = 6;
            this.MealPlanGridView.SelectionChanged += new System.EventHandler(this.MealPlanGridViewSelectionChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(1021, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 19);
            this.label2.TabIndex = 5;
            this.label2.Text = "Meal Plan";
            // 
            // LocationInfoGridView
            // 
            this.LocationInfoGridView.AllowUserToAddRows = false;
            this.LocationInfoGridView.AllowUserToDeleteRows = false;
            this.LocationInfoGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.LocationInfoGridView.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.LocationInfoGridView.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.LocationInfoGridView.CausesValidation = false;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.DarkSeaGreen;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.DarkSeaGreen;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.LocationInfoGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.LocationInfoGridView.ColumnHeadersHeight = 29;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.PaleGreen;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.LocationInfoGridView.DefaultCellStyle = dataGridViewCellStyle6;
            this.LocationInfoGridView.EnableHeadersVisualStyles = false;
            this.LocationInfoGridView.GridColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.LocationInfoGridView.Location = new System.Drawing.Point(489, 54);
            this.LocationInfoGridView.MultiSelect = false;
            this.LocationInfoGridView.Name = "LocationInfoGridView";
            this.LocationInfoGridView.ReadOnly = true;
            this.LocationInfoGridView.RowHeadersWidth = 51;
            this.LocationInfoGridView.RowTemplate.Height = 24;
            this.LocationInfoGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.LocationInfoGridView.Size = new System.Drawing.Size(471, 151);
            this.LocationInfoGridView.TabIndex = 3;
            this.LocationInfoGridView.SelectionChanged += new System.EventHandler(this.LocationInfoGridSelectionChanged);
            // 
            // EventLocationLabel
            // 
            this.EventLocationLabel.AutoSize = true;
            this.EventLocationLabel.Font = new System.Drawing.Font("Times New Roman", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EventLocationLabel.Location = new System.Drawing.Point(485, 23);
            this.EventLocationLabel.Name = "EventLocationLabel";
            this.EventLocationLabel.Size = new System.Drawing.Size(121, 19);
            this.EventLocationLabel.TabIndex = 2;
            this.EventLocationLabel.Text = "Event Location";
            // 
            // EventsLabel
            // 
            this.EventsLabel.AutoSize = true;
            this.EventsLabel.Font = new System.Drawing.Font("Times New Roman", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EventsLabel.Location = new System.Drawing.Point(22, 23);
            this.EventsLabel.Name = "EventsLabel";
            this.EventsLabel.Size = new System.Drawing.Size(162, 19);
            this.EventsLabel.TabIndex = 1;
            this.EventsLabel.Text = "Team Builder Events";
            // 
            // EventInfoGridView
            // 
            this.EventInfoGridView.AllowUserToAddRows = false;
            this.EventInfoGridView.AllowUserToDeleteRows = false;
            this.EventInfoGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.EventInfoGridView.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.EventInfoGridView.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.EventInfoGridView.CausesValidation = false;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.DarkSeaGreen;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.DarkSeaGreen;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.EventInfoGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.EventInfoGridView.ColumnHeadersHeight = 29;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.PaleGreen;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.EventInfoGridView.DefaultCellStyle = dataGridViewCellStyle8;
            this.EventInfoGridView.EnableHeadersVisualStyles = false;
            this.EventInfoGridView.GridColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.EventInfoGridView.Location = new System.Drawing.Point(26, 54);
            this.EventInfoGridView.MultiSelect = false;
            this.EventInfoGridView.Name = "EventInfoGridView";
            this.EventInfoGridView.ReadOnly = true;
            this.EventInfoGridView.RowHeadersWidth = 51;
            this.EventInfoGridView.RowTemplate.Height = 24;
            this.EventInfoGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.EventInfoGridView.Size = new System.Drawing.Size(444, 271);
            this.EventInfoGridView.TabIndex = 0;
            this.EventInfoGridView.SelectionChanged += new System.EventHandler(this.EventInfoGridSelectionChanged);
            // 
            // ManagementReportTooltip
            // 
            this.ManagementReportTooltip.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            // 
            // SaveToolTip
            // 
            this.SaveToolTip.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Warning;
            // 
            // ClearSelectionTooltip
            // 
            this.ClearSelectionTooltip.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            // 
            // CompleteOrderTooltip
            // 
            this.CompleteOrderTooltip.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            // 
            // ResetTooltip
            // 
            this.ResetTooltip.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            // 
            // TeamBuilderV2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.AutoSize = true;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(1246, 595);
            this.Controls.Add(this.HomePageGroupBox);
            this.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "TeamBuilderV2";
            this.Text = "TeamBuilder V2.0";
            this.HomePageGroupBox.ResumeLayout(false);
            this.HomePageGroupBox.PerformLayout();
            this.RunningTotalGroupBox.ResumeLayout(false);
            this.RunningTotalGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BookingInfoGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MealPlanGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LocationInfoGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.EventInfoGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox HomePageGroupBox;
        private System.Windows.Forms.DataGridView EventInfoGridView;
        private System.Windows.Forms.Label EventsLabel;
        private System.Windows.Forms.Label EventLocationLabel;
        private System.Windows.Forms.DataGridView LocationInfoGridView;
        private System.Windows.Forms.DataGridView MealPlanGridView;
        private System.Windows.Forms.Label label2;
        private Button ClearButton;
        private DataGridView BookingInfoGridView;
        private Button ConfirmOrderButton;
        private Label BookingInfoLabel;
        private Button AddToBookingButton;
        private Label Note2Label;
        private Button Exit;
        private PictureBox pictureBox1;
        private Button ResetButton;
        private Button GenerateManagementReport;
        private GroupBox RunningTotalGroupBox;
        private Label RunningTotalLabel;
        private TextBox RunningTotalTextBox;
        private ToolTip ManagementReportTooltip;
        private ToolTip SaveToolTip;
        private ToolTip ClearSelectionTooltip;
        private ToolTip ResetTooltip;
        private ToolTip AddToBookingTooltip;
        private ToolTip CompleteOrderTooltip;
    }
}

