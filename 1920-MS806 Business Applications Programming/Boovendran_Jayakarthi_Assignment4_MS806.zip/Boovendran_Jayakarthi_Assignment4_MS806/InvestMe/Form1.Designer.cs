﻿namespace InvestMe
{
    partial class InvestMeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(InvestMeForm));
            this.NewInvestmentButton = new System.Windows.Forms.Button();
            this.SummaryButton = new System.Windows.Forms.Button();
            this.ExitButton = new System.Windows.Forms.Button();
            this.HomePageGroupBox = new System.Windows.Forms.GroupBox();
            this.LogoBox = new System.Windows.Forms.PictureBox();
            this.InvestmentGroupBox = new System.Windows.Forms.GroupBox();
            this.HomePageButton = new System.Windows.Forms.Button();
            this.EditSelectionButton = new System.Windows.Forms.Button();
            this.ExitButton2 = new System.Windows.Forms.Button();
            this.CustomerInfoGroupBox = new System.Windows.Forms.GroupBox();
            this.ConfirmPlanButton = new System.Windows.Forms.Button();
            this.ClearButton = new System.Windows.Forms.Button();
            this.TransactionIDTextBox = new System.Windows.Forms.TextBox();
            this.EmailIDTextBox = new System.Windows.Forms.TextBox();
            this.TelephoneNumberTextBox = new System.Windows.Forms.TextBox();
            this.CustomerNameTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.EmailLabel = new System.Windows.Forms.Label();
            this.TelephoneNumberLabel = new System.Windows.Forms.Label();
            this.CustomerNameLabel = new System.Windows.Forms.Label();
            this.InvestmentDetailsGrid = new System.Windows.Forms.DataGridView();
            this.ProceedButton = new System.Windows.Forms.Button();
            this.DisplayButton = new System.Windows.Forms.Button();
            this.PrincipleInvestmentAmountTextBox = new System.Windows.Forms.TextBox();
            this.InvestmentAmountLabel = new System.Windows.Forms.Label();
            this.InvestmentConfirmationGroupBox = new System.Windows.Forms.GroupBox();
            this.EditInvestmentButton = new System.Windows.Forms.Button();
            this.ConfirmInvestmentButton = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.ROIConfirmationTextBox = new System.Windows.Forms.TextBox();
            this.InterestAmountConfirmationTextBox = new System.Windows.Forms.TextBox();
            this.InterestRateConfirmationTextBox = new System.Windows.Forms.TextBox();
            this.InvestmentTermConfirmationTextBox = new System.Windows.Forms.TextBox();
            this.InvestmentAmountConfirmationTextBox = new System.Windows.Forms.TextBox();
            this.TransactionIDConfirmationTextBox = new System.Windows.Forms.TextBox();
            this.ContactNumberConfirmationTextBox = new System.Windows.Forms.TextBox();
            this.EmailIDConfirmationTextBox = new System.Windows.Forms.TextBox();
            this.NameConfirmationTextBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.InvestedAmountLabel = new System.Windows.Forms.Label();
            this.TransactionIdLabel = new System.Windows.Forms.Label();
            this.TransactionDetailsLabel = new System.Windows.Forms.Label();
            this.ContactNumberLabel = new System.Windows.Forms.Label();
            this.EmailIDLabel = new System.Windows.Forms.Label();
            this.NameLabel = new System.Windows.Forms.Label();
            this.CustomerInfoLabel = new System.Windows.Forms.Label();
            this.SummaryGroupBox = new System.Windows.Forms.GroupBox();
            this.ExitSummaryButton = new System.Windows.Forms.Button();
            this.HomePageButton2 = new System.Windows.Forms.Button();
            this.SummaryLabel7 = new System.Windows.Forms.Label();
            this.ResetButton = new System.Windows.Forms.Button();
            this.SearchButton = new System.Windows.Forms.Button();
            this.SearchKeyTextBox = new System.Windows.Forms.TextBox();
            this.SummaryGrid = new System.Windows.Forms.DataGridView();
            this.SearchTooltip = new System.Windows.Forms.ToolTip(this.components);
            this.ResetTooltip = new System.Windows.Forms.ToolTip(this.components);
            this.HomePageTooltip = new System.Windows.Forms.ToolTip(this.components);
            this.ExitTooltip = new System.Windows.Forms.ToolTip(this.components);
            this.TotalInvestmentLabel = new System.Windows.Forms.Label();
            this.TotalTransactionTextBox = new System.Windows.Forms.TextBox();
            this.TotalInterestLabel = new System.Windows.Forms.Label();
            this.TotalInterestTextBox = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.AverageTermTextBox = new System.Windows.Forms.TextBox();
            this.TotalInvestmentTextBox = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.DisplayToolTip = new System.Windows.Forms.ToolTip(this.components);
            this.EditSelectionTooltip = new System.Windows.Forms.ToolTip(this.components);
            this.ProceedTooltip = new System.Windows.Forms.ToolTip(this.components);
            this.ClearToolTip = new System.Windows.Forms.ToolTip(this.components);
            this.ConfirmTooltip = new System.Windows.Forms.ToolTip(this.components);
            this.HomePageGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LogoBox)).BeginInit();
            this.InvestmentGroupBox.SuspendLayout();
            this.CustomerInfoGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.InvestmentDetailsGrid)).BeginInit();
            this.InvestmentConfirmationGroupBox.SuspendLayout();
            this.SummaryGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SummaryGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // NewInvestmentButton
            // 
            this.NewInvestmentButton.BackColor = System.Drawing.Color.PaleGreen;
            this.NewInvestmentButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.NewInvestmentButton.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NewInvestmentButton.ForeColor = System.Drawing.Color.Black;
            this.NewInvestmentButton.Location = new System.Drawing.Point(72, 386);
            this.NewInvestmentButton.Name = "NewInvestmentButton";
            this.NewInvestmentButton.Size = new System.Drawing.Size(201, 47);
            this.NewInvestmentButton.TabIndex = 1;
            this.NewInvestmentButton.Text = "&New Investment";
            this.NewInvestmentButton.UseVisualStyleBackColor = false;
            this.NewInvestmentButton.Click += new System.EventHandler(this.NewInvestmentButton_Click);
            // 
            // SummaryButton
            // 
            this.SummaryButton.BackColor = System.Drawing.Color.LightYellow;
            this.SummaryButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.SummaryButton.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SummaryButton.ForeColor = System.Drawing.Color.Black;
            this.SummaryButton.Location = new System.Drawing.Point(372, 385);
            this.SummaryButton.Name = "SummaryButton";
            this.SummaryButton.Size = new System.Drawing.Size(201, 47);
            this.SummaryButton.TabIndex = 2;
            this.SummaryButton.Text = "Investment &Summary";
            this.SummaryButton.UseVisualStyleBackColor = false;
            this.SummaryButton.Click += new System.EventHandler(this.SummaryButton_Click);
            // 
            // ExitButton
            // 
            this.ExitButton.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ExitButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ExitButton.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ExitButton.ForeColor = System.Drawing.Color.Black;
            this.ExitButton.Location = new System.Drawing.Point(223, 483);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(201, 47);
            this.ExitButton.TabIndex = 3;
            this.ExitButton.Text = "&Close InvestMe";
            this.ExitButton.UseVisualStyleBackColor = false;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // HomePageGroupBox
            // 
            this.HomePageGroupBox.BackColor = System.Drawing.Color.Honeydew;
            this.HomePageGroupBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.HomePageGroupBox.Controls.Add(this.LogoBox);
            this.HomePageGroupBox.Controls.Add(this.NewInvestmentButton);
            this.HomePageGroupBox.Controls.Add(this.ExitButton);
            this.HomePageGroupBox.Controls.Add(this.SummaryButton);
            this.HomePageGroupBox.Location = new System.Drawing.Point(177, 4);
            this.HomePageGroupBox.Name = "HomePageGroupBox";
            this.HomePageGroupBox.Size = new System.Drawing.Size(651, 734);
            this.HomePageGroupBox.TabIndex = 4;
            this.HomePageGroupBox.TabStop = false;
            // 
            // LogoBox
            // 
            this.LogoBox.Image = global::InvestMe.Properties.Resources.InvestMeLogo;
            this.LogoBox.Location = new System.Drawing.Point(182, 85);
            this.LogoBox.Name = "LogoBox";
            this.LogoBox.Size = new System.Drawing.Size(296, 229);
            this.LogoBox.TabIndex = 4;
            this.LogoBox.TabStop = false;
            // 
            // InvestmentGroupBox
            // 
            this.InvestmentGroupBox.BackColor = System.Drawing.Color.LavenderBlush;
            this.InvestmentGroupBox.Controls.Add(this.HomePageButton);
            this.InvestmentGroupBox.Controls.Add(this.EditSelectionButton);
            this.InvestmentGroupBox.Controls.Add(this.ExitButton2);
            this.InvestmentGroupBox.Controls.Add(this.CustomerInfoGroupBox);
            this.InvestmentGroupBox.Controls.Add(this.InvestmentDetailsGrid);
            this.InvestmentGroupBox.Controls.Add(this.ProceedButton);
            this.InvestmentGroupBox.Controls.Add(this.DisplayButton);
            this.InvestmentGroupBox.Controls.Add(this.PrincipleInvestmentAmountTextBox);
            this.InvestmentGroupBox.Controls.Add(this.InvestmentAmountLabel);
            this.InvestmentGroupBox.ForeColor = System.Drawing.Color.Black;
            this.InvestmentGroupBox.Location = new System.Drawing.Point(102, 30);
            this.InvestmentGroupBox.Name = "InvestmentGroupBox";
            this.InvestmentGroupBox.Size = new System.Drawing.Size(770, 689);
            this.InvestmentGroupBox.TabIndex = 5;
            this.InvestmentGroupBox.TabStop = false;
            // 
            // HomePageButton
            // 
            this.HomePageButton.BackColor = System.Drawing.SystemColors.ControlLight;
            this.HomePageButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.HomePageButton.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HomePageButton.Location = new System.Drawing.Point(78, 627);
            this.HomePageButton.Name = "HomePageButton";
            this.HomePageButton.Size = new System.Drawing.Size(136, 38);
            this.HomePageButton.TabIndex = 9;
            this.HomePageButton.Text = "< &Home Page";
            this.HomePageTooltip.SetToolTip(this.HomePageButton, "Click to Return to Home Page");
            this.HomePageButton.UseVisualStyleBackColor = false;
            this.HomePageButton.Click += new System.EventHandler(this.HomePageButton_Click);
            // 
            // EditSelectionButton
            // 
            this.EditSelectionButton.BackColor = System.Drawing.SystemColors.ControlLight;
            this.EditSelectionButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.EditSelectionButton.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EditSelectionButton.Location = new System.Drawing.Point(78, 281);
            this.EditSelectionButton.Name = "EditSelectionButton";
            this.EditSelectionButton.Size = new System.Drawing.Size(136, 38);
            this.EditSelectionButton.TabIndex = 8;
            this.EditSelectionButton.Text = "&Edit Selection";
            this.EditSelectionTooltip.SetToolTip(this.EditSelectionButton, "Click to Edit Selected Investment Plan");
            this.EditSelectionButton.UseVisualStyleBackColor = false;
            this.EditSelectionButton.Click += new System.EventHandler(this.EditSelectionButton_Click);
            // 
            // ExitButton2
            // 
            this.ExitButton2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ExitButton2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ExitButton2.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ExitButton2.Location = new System.Drawing.Point(575, 628);
            this.ExitButton2.Name = "ExitButton2";
            this.ExitButton2.Size = new System.Drawing.Size(112, 37);
            this.ExitButton2.TabIndex = 7;
            this.ExitButton2.Text = "E&xit";
            this.ExitTooltip.SetToolTip(this.ExitButton2, "Click to Exit Application");
            this.ExitButton2.UseVisualStyleBackColor = false;
            this.ExitButton2.Click += new System.EventHandler(this.ExitButton2_Click);
            // 
            // CustomerInfoGroupBox
            // 
            this.CustomerInfoGroupBox.Controls.Add(this.ConfirmPlanButton);
            this.CustomerInfoGroupBox.Controls.Add(this.ClearButton);
            this.CustomerInfoGroupBox.Controls.Add(this.TransactionIDTextBox);
            this.CustomerInfoGroupBox.Controls.Add(this.EmailIDTextBox);
            this.CustomerInfoGroupBox.Controls.Add(this.TelephoneNumberTextBox);
            this.CustomerInfoGroupBox.Controls.Add(this.CustomerNameTextBox);
            this.CustomerInfoGroupBox.Controls.Add(this.label1);
            this.CustomerInfoGroupBox.Controls.Add(this.EmailLabel);
            this.CustomerInfoGroupBox.Controls.Add(this.TelephoneNumberLabel);
            this.CustomerInfoGroupBox.Controls.Add(this.CustomerNameLabel);
            this.CustomerInfoGroupBox.Location = new System.Drawing.Point(59, 346);
            this.CustomerInfoGroupBox.Name = "CustomerInfoGroupBox";
            this.CustomerInfoGroupBox.Size = new System.Drawing.Size(681, 245);
            this.CustomerInfoGroupBox.TabIndex = 6;
            this.CustomerInfoGroupBox.TabStop = false;
            // 
            // ConfirmPlanButton
            // 
            this.ConfirmPlanButton.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ConfirmPlanButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ConfirmPlanButton.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ConfirmPlanButton.Location = new System.Drawing.Point(516, 148);
            this.ConfirmPlanButton.Name = "ConfirmPlanButton";
            this.ConfirmPlanButton.Size = new System.Drawing.Size(112, 37);
            this.ConfirmPlanButton.TabIndex = 9;
            this.ConfirmPlanButton.Text = "Con&firm";
            this.ConfirmTooltip.SetToolTip(this.ConfirmPlanButton, "Click to Confirm User Info");
            this.ConfirmPlanButton.UseVisualStyleBackColor = false;
            this.ConfirmPlanButton.Click += new System.EventHandler(this.ConfirmPlanButton_Click);
            // 
            // ClearButton
            // 
            this.ClearButton.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ClearButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ClearButton.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ClearButton.Location = new System.Drawing.Point(516, 61);
            this.ClearButton.Name = "ClearButton";
            this.ClearButton.Size = new System.Drawing.Size(112, 37);
            this.ClearButton.TabIndex = 8;
            this.ClearButton.Text = "&Clear";
            this.ClearToolTip.SetToolTip(this.ClearButton, "Click to Clear User Info");
            this.ClearButton.UseVisualStyleBackColor = false;
            this.ClearButton.Click += new System.EventHandler(this.ClearButton_Click);
            // 
            // TransactionIDTextBox
            // 
            this.TransactionIDTextBox.Cursor = System.Windows.Forms.Cursors.No;
            this.TransactionIDTextBox.Location = new System.Drawing.Point(254, 185);
            this.TransactionIDTextBox.Name = "TransactionIDTextBox";
            this.TransactionIDTextBox.ReadOnly = true;
            this.TransactionIDTextBox.Size = new System.Drawing.Size(162, 27);
            this.TransactionIDTextBox.TabIndex = 7;
            this.TransactionIDTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // EmailIDTextBox
            // 
            this.EmailIDTextBox.Location = new System.Drawing.Point(254, 136);
            this.EmailIDTextBox.Name = "EmailIDTextBox";
            this.EmailIDTextBox.Size = new System.Drawing.Size(162, 27);
            this.EmailIDTextBox.TabIndex = 6;
            this.EmailIDTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TelephoneNumberTextBox
            // 
            this.TelephoneNumberTextBox.Location = new System.Drawing.Point(254, 86);
            this.TelephoneNumberTextBox.Name = "TelephoneNumberTextBox";
            this.TelephoneNumberTextBox.Size = new System.Drawing.Size(162, 27);
            this.TelephoneNumberTextBox.TabIndex = 5;
            this.TelephoneNumberTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // CustomerNameTextBox
            // 
            this.CustomerNameTextBox.Location = new System.Drawing.Point(254, 43);
            this.CustomerNameTextBox.Name = "CustomerNameTextBox";
            this.CustomerNameTextBox.Size = new System.Drawing.Size(162, 27);
            this.CustomerNameTextBox.TabIndex = 4;
            this.CustomerNameTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(94, 188);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(108, 19);
            this.label1.TabIndex = 3;
            this.label1.Text = "Transaction ID";
            // 
            // EmailLabel
            // 
            this.EmailLabel.AutoSize = true;
            this.EmailLabel.Location = new System.Drawing.Point(132, 139);
            this.EmailLabel.Name = "EmailLabel";
            this.EmailLabel.Size = new System.Drawing.Size(70, 19);
            this.EmailLabel.TabIndex = 2;
            this.EmailLabel.Text = "Email ID";
            // 
            // TelephoneNumberLabel
            // 
            this.TelephoneNumberLabel.AutoSize = true;
            this.TelephoneNumberLabel.Location = new System.Drawing.Point(73, 94);
            this.TelephoneNumberLabel.Name = "TelephoneNumberLabel";
            this.TelephoneNumberLabel.Size = new System.Drawing.Size(138, 19);
            this.TelephoneNumberLabel.TabIndex = 1;
            this.TelephoneNumberLabel.Text = "Telephone Number";
            // 
            // CustomerNameLabel
            // 
            this.CustomerNameLabel.AutoSize = true;
            this.CustomerNameLabel.Location = new System.Drawing.Point(87, 43);
            this.CustomerNameLabel.Name = "CustomerNameLabel";
            this.CustomerNameLabel.Size = new System.Drawing.Size(124, 19);
            this.CustomerNameLabel.TabIndex = 0;
            this.CustomerNameLabel.Text = "Customer Name ";
            // 
            // InvestmentDetailsGrid
            // 
            this.InvestmentDetailsGrid.AllowUserToAddRows = false;
            this.InvestmentDetailsGrid.AllowUserToDeleteRows = false;
            this.InvestmentDetailsGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader;
            this.InvestmentDetailsGrid.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.InvestmentDetailsGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.InvestmentDetailsGrid.Cursor = System.Windows.Forms.Cursors.Hand;
            this.InvestmentDetailsGrid.GridColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.InvestmentDetailsGrid.Location = new System.Drawing.Point(41, 116);
            this.InvestmentDetailsGrid.Name = "InvestmentDetailsGrid";
            this.InvestmentDetailsGrid.ReadOnly = true;
            this.InvestmentDetailsGrid.RowHeadersWidth = 51;
            this.InvestmentDetailsGrid.RowTemplate.Height = 24;
            this.InvestmentDetailsGrid.Size = new System.Drawing.Size(699, 140);
            this.InvestmentDetailsGrid.TabIndex = 5;
            // 
            // ProceedButton
            // 
            this.ProceedButton.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ProceedButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ProceedButton.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ProceedButton.Location = new System.Drawing.Point(575, 281);
            this.ProceedButton.Name = "ProceedButton";
            this.ProceedButton.Size = new System.Drawing.Size(112, 38);
            this.ProceedButton.TabIndex = 4;
            this.ProceedButton.Text = "&Proceed";
            this.ProceedTooltip.SetToolTip(this.ProceedButton, "Click to Proceed to User Info");
            this.ProceedButton.UseVisualStyleBackColor = false;
            this.ProceedButton.Click += new System.EventHandler(this.ProceedButton_Click);
            // 
            // DisplayButton
            // 
            this.DisplayButton.BackColor = System.Drawing.SystemColors.ControlLight;
            this.DisplayButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.DisplayButton.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DisplayButton.Location = new System.Drawing.Point(575, 59);
            this.DisplayButton.Name = "DisplayButton";
            this.DisplayButton.Size = new System.Drawing.Size(112, 34);
            this.DisplayButton.TabIndex = 2;
            this.DisplayButton.Text = "&Display";
            this.DisplayToolTip.SetToolTip(this.DisplayButton, "Click to Display Investment Plans");
            this.DisplayButton.UseVisualStyleBackColor = false;
            this.DisplayButton.Click += new System.EventHandler(this.DisplayButton_Click);
            // 
            // PrincipleInvestmentAmountTextBox
            // 
            this.PrincipleInvestmentAmountTextBox.Location = new System.Drawing.Point(376, 59);
            this.PrincipleInvestmentAmountTextBox.Name = "PrincipleInvestmentAmountTextBox";
            this.PrincipleInvestmentAmountTextBox.Size = new System.Drawing.Size(153, 27);
            this.PrincipleInvestmentAmountTextBox.TabIndex = 1;
            this.PrincipleInvestmentAmountTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // InvestmentAmountLabel
            // 
            this.InvestmentAmountLabel.AutoSize = true;
            this.InvestmentAmountLabel.Font = new System.Drawing.Font("Times New Roman", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InvestmentAmountLabel.Location = new System.Drawing.Point(93, 62);
            this.InvestmentAmountLabel.Name = "InvestmentAmountLabel";
            this.InvestmentAmountLabel.Size = new System.Drawing.Size(236, 19);
            this.InvestmentAmountLabel.TabIndex = 0;
            this.InvestmentAmountLabel.Text = "Principle Investment Amount :";
            // 
            // InvestmentConfirmationGroupBox
            // 
            this.InvestmentConfirmationGroupBox.BackColor = System.Drawing.Color.LightYellow;
            this.InvestmentConfirmationGroupBox.Controls.Add(this.EditInvestmentButton);
            this.InvestmentConfirmationGroupBox.Controls.Add(this.ConfirmInvestmentButton);
            this.InvestmentConfirmationGroupBox.Controls.Add(this.label6);
            this.InvestmentConfirmationGroupBox.Controls.Add(this.ROIConfirmationTextBox);
            this.InvestmentConfirmationGroupBox.Controls.Add(this.InterestAmountConfirmationTextBox);
            this.InvestmentConfirmationGroupBox.Controls.Add(this.InterestRateConfirmationTextBox);
            this.InvestmentConfirmationGroupBox.Controls.Add(this.InvestmentTermConfirmationTextBox);
            this.InvestmentConfirmationGroupBox.Controls.Add(this.InvestmentAmountConfirmationTextBox);
            this.InvestmentConfirmationGroupBox.Controls.Add(this.TransactionIDConfirmationTextBox);
            this.InvestmentConfirmationGroupBox.Controls.Add(this.ContactNumberConfirmationTextBox);
            this.InvestmentConfirmationGroupBox.Controls.Add(this.EmailIDConfirmationTextBox);
            this.InvestmentConfirmationGroupBox.Controls.Add(this.NameConfirmationTextBox);
            this.InvestmentConfirmationGroupBox.Controls.Add(this.label5);
            this.InvestmentConfirmationGroupBox.Controls.Add(this.label4);
            this.InvestmentConfirmationGroupBox.Controls.Add(this.label3);
            this.InvestmentConfirmationGroupBox.Controls.Add(this.label2);
            this.InvestmentConfirmationGroupBox.Controls.Add(this.InvestedAmountLabel);
            this.InvestmentConfirmationGroupBox.Controls.Add(this.TransactionIdLabel);
            this.InvestmentConfirmationGroupBox.Controls.Add(this.TransactionDetailsLabel);
            this.InvestmentConfirmationGroupBox.Controls.Add(this.ContactNumberLabel);
            this.InvestmentConfirmationGroupBox.Controls.Add(this.EmailIDLabel);
            this.InvestmentConfirmationGroupBox.Controls.Add(this.NameLabel);
            this.InvestmentConfirmationGroupBox.Controls.Add(this.CustomerInfoLabel);
            this.InvestmentConfirmationGroupBox.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.InvestmentConfirmationGroupBox.Location = new System.Drawing.Point(65, 56);
            this.InvestmentConfirmationGroupBox.Name = "InvestmentConfirmationGroupBox";
            this.InvestmentConfirmationGroupBox.Size = new System.Drawing.Size(838, 639);
            this.InvestmentConfirmationGroupBox.TabIndex = 6;
            this.InvestmentConfirmationGroupBox.TabStop = false;
            // 
            // EditInvestmentButton
            // 
            this.EditInvestmentButton.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EditInvestmentButton.Location = new System.Drawing.Point(628, 567);
            this.EditInvestmentButton.Name = "EditInvestmentButton";
            this.EditInvestmentButton.Size = new System.Drawing.Size(95, 31);
            this.EditInvestmentButton.TabIndex = 22;
            this.EditInvestmentButton.Text = "&Edit";
            this.EditInvestmentButton.UseVisualStyleBackColor = true;
            this.EditInvestmentButton.Click += new System.EventHandler(this.EditInvestmentButton_Click);
            // 
            // ConfirmInvestmentButton
            // 
            this.ConfirmInvestmentButton.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ConfirmInvestmentButton.Location = new System.Drawing.Point(628, 513);
            this.ConfirmInvestmentButton.Name = "ConfirmInvestmentButton";
            this.ConfirmInvestmentButton.Size = new System.Drawing.Size(95, 33);
            this.ConfirmInvestmentButton.TabIndex = 21;
            this.ConfirmInvestmentButton.Text = "Confir&m";
            this.ConfirmInvestmentButton.UseVisualStyleBackColor = true;
            this.ConfirmInvestmentButton.Click += new System.EventHandler(this.ConfirmInvestmentButton_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.DarkBlue;
            this.label6.Location = new System.Drawing.Point(48, 23);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(195, 19);
            this.label6.TabIndex = 20;
            this.label6.Text = "Investment Confirmation";
            // 
            // ROIConfirmationTextBox
            // 
            this.ROIConfirmationTextBox.Location = new System.Drawing.Point(280, 570);
            this.ROIConfirmationTextBox.Name = "ROIConfirmationTextBox";
            this.ROIConfirmationTextBox.ReadOnly = true;
            this.ROIConfirmationTextBox.Size = new System.Drawing.Size(265, 27);
            this.ROIConfirmationTextBox.TabIndex = 19;
            this.ROIConfirmationTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // InterestAmountConfirmationTextBox
            // 
            this.InterestAmountConfirmationTextBox.Location = new System.Drawing.Point(280, 517);
            this.InterestAmountConfirmationTextBox.Name = "InterestAmountConfirmationTextBox";
            this.InterestAmountConfirmationTextBox.ReadOnly = true;
            this.InterestAmountConfirmationTextBox.Size = new System.Drawing.Size(265, 27);
            this.InterestAmountConfirmationTextBox.TabIndex = 18;
            this.InterestAmountConfirmationTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // InterestRateConfirmationTextBox
            // 
            this.InterestRateConfirmationTextBox.Location = new System.Drawing.Point(280, 458);
            this.InterestRateConfirmationTextBox.Name = "InterestRateConfirmationTextBox";
            this.InterestRateConfirmationTextBox.ReadOnly = true;
            this.InterestRateConfirmationTextBox.Size = new System.Drawing.Size(265, 27);
            this.InterestRateConfirmationTextBox.TabIndex = 17;
            this.InterestRateConfirmationTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // InvestmentTermConfirmationTextBox
            // 
            this.InvestmentTermConfirmationTextBox.Location = new System.Drawing.Point(280, 405);
            this.InvestmentTermConfirmationTextBox.Name = "InvestmentTermConfirmationTextBox";
            this.InvestmentTermConfirmationTextBox.ReadOnly = true;
            this.InvestmentTermConfirmationTextBox.Size = new System.Drawing.Size(265, 27);
            this.InvestmentTermConfirmationTextBox.TabIndex = 16;
            this.InvestmentTermConfirmationTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // InvestmentAmountConfirmationTextBox
            // 
            this.InvestmentAmountConfirmationTextBox.Location = new System.Drawing.Point(280, 354);
            this.InvestmentAmountConfirmationTextBox.Name = "InvestmentAmountConfirmationTextBox";
            this.InvestmentAmountConfirmationTextBox.ReadOnly = true;
            this.InvestmentAmountConfirmationTextBox.Size = new System.Drawing.Size(265, 27);
            this.InvestmentAmountConfirmationTextBox.TabIndex = 15;
            this.InvestmentAmountConfirmationTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TransactionIDConfirmationTextBox
            // 
            this.TransactionIDConfirmationTextBox.Location = new System.Drawing.Point(280, 300);
            this.TransactionIDConfirmationTextBox.Name = "TransactionIDConfirmationTextBox";
            this.TransactionIDConfirmationTextBox.ReadOnly = true;
            this.TransactionIDConfirmationTextBox.Size = new System.Drawing.Size(265, 27);
            this.TransactionIDConfirmationTextBox.TabIndex = 14;
            this.TransactionIDConfirmationTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // ContactNumberConfirmationTextBox
            // 
            this.ContactNumberConfirmationTextBox.Location = new System.Drawing.Point(280, 199);
            this.ContactNumberConfirmationTextBox.Name = "ContactNumberConfirmationTextBox";
            this.ContactNumberConfirmationTextBox.ReadOnly = true;
            this.ContactNumberConfirmationTextBox.Size = new System.Drawing.Size(265, 27);
            this.ContactNumberConfirmationTextBox.TabIndex = 13;
            this.ContactNumberConfirmationTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // EmailIDConfirmationTextBox
            // 
            this.EmailIDConfirmationTextBox.Location = new System.Drawing.Point(280, 146);
            this.EmailIDConfirmationTextBox.Name = "EmailIDConfirmationTextBox";
            this.EmailIDConfirmationTextBox.ReadOnly = true;
            this.EmailIDConfirmationTextBox.Size = new System.Drawing.Size(265, 27);
            this.EmailIDConfirmationTextBox.TabIndex = 12;
            this.EmailIDConfirmationTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // NameConfirmationTextBox
            // 
            this.NameConfirmationTextBox.Location = new System.Drawing.Point(280, 101);
            this.NameConfirmationTextBox.Name = "NameConfirmationTextBox";
            this.NameConfirmationTextBox.ReadOnly = true;
            this.NameConfirmationTextBox.Size = new System.Drawing.Size(265, 27);
            this.NameConfirmationTextBox.TabIndex = 11;
            this.NameConfirmationTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(42, 573);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(198, 19);
            this.label5.TabIndex = 10;
            this.label5.Text = "Return on Investment (ROI)";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(85, 520);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(155, 19);
            this.label4.TabIndex = 9;
            this.label4.Text = "Compounded Interest";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(144, 461);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(96, 19);
            this.label3.TabIndex = 8;
            this.label3.Text = "Interest Rate";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(118, 408);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(122, 19);
            this.label2.TabIndex = 7;
            this.label2.Text = "Investment Term";
            // 
            // InvestedAmountLabel
            // 
            this.InvestedAmountLabel.AutoSize = true;
            this.InvestedAmountLabel.Location = new System.Drawing.Point(100, 357);
            this.InvestedAmountLabel.Name = "InvestedAmountLabel";
            this.InvestedAmountLabel.Size = new System.Drawing.Size(140, 19);
            this.InvestedAmountLabel.TabIndex = 6;
            this.InvestedAmountLabel.Text = "Investment Amount";
            // 
            // TransactionIdLabel
            // 
            this.TransactionIdLabel.AutoSize = true;
            this.TransactionIdLabel.Location = new System.Drawing.Point(132, 303);
            this.TransactionIdLabel.Name = "TransactionIdLabel";
            this.TransactionIdLabel.Size = new System.Drawing.Size(108, 19);
            this.TransactionIdLabel.TabIndex = 5;
            this.TransactionIdLabel.Text = "Transaction ID";
            // 
            // TransactionDetailsLabel
            // 
            this.TransactionDetailsLabel.AutoSize = true;
            this.TransactionDetailsLabel.Font = new System.Drawing.Font("Times New Roman", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TransactionDetailsLabel.Location = new System.Drawing.Point(87, 243);
            this.TransactionDetailsLabel.Name = "TransactionDetailsLabel";
            this.TransactionDetailsLabel.Size = new System.Drawing.Size(153, 19);
            this.TransactionDetailsLabel.TabIndex = 4;
            this.TransactionDetailsLabel.Text = "Transaction Details";
            // 
            // ContactNumberLabel
            // 
            this.ContactNumberLabel.AutoSize = true;
            this.ContactNumberLabel.Location = new System.Drawing.Point(123, 202);
            this.ContactNumberLabel.Name = "ContactNumberLabel";
            this.ContactNumberLabel.Size = new System.Drawing.Size(117, 19);
            this.ContactNumberLabel.TabIndex = 3;
            this.ContactNumberLabel.Text = "ContactNumber";
            // 
            // EmailIDLabel
            // 
            this.EmailIDLabel.AutoSize = true;
            this.EmailIDLabel.Location = new System.Drawing.Point(173, 149);
            this.EmailIDLabel.Name = "EmailIDLabel";
            this.EmailIDLabel.Size = new System.Drawing.Size(70, 19);
            this.EmailIDLabel.TabIndex = 2;
            this.EmailIDLabel.Text = "Email ID";
            // 
            // NameLabel
            // 
            this.NameLabel.AutoSize = true;
            this.NameLabel.Location = new System.Drawing.Point(191, 104);
            this.NameLabel.Name = "NameLabel";
            this.NameLabel.Size = new System.Drawing.Size(49, 19);
            this.NameLabel.TabIndex = 1;
            this.NameLabel.Text = "Name";
            // 
            // CustomerInfoLabel
            // 
            this.CustomerInfoLabel.AutoSize = true;
            this.CustomerInfoLabel.Font = new System.Drawing.Font("Times New Roman", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CustomerInfoLabel.Location = new System.Drawing.Point(125, 54);
            this.CustomerInfoLabel.Name = "CustomerInfoLabel";
            this.CustomerInfoLabel.Size = new System.Drawing.Size(115, 19);
            this.CustomerInfoLabel.TabIndex = 0;
            this.CustomerInfoLabel.Text = "Customer Info";
            // 
            // SummaryGroupBox
            // 
            this.SummaryGroupBox.BackColor = System.Drawing.Color.AliceBlue;
            this.SummaryGroupBox.Controls.Add(this.label8);
            this.SummaryGroupBox.Controls.Add(this.TotalInvestmentTextBox);
            this.SummaryGroupBox.Controls.Add(this.AverageTermTextBox);
            this.SummaryGroupBox.Controls.Add(this.label7);
            this.SummaryGroupBox.Controls.Add(this.TotalInterestTextBox);
            this.SummaryGroupBox.Controls.Add(this.TotalInterestLabel);
            this.SummaryGroupBox.Controls.Add(this.TotalTransactionTextBox);
            this.SummaryGroupBox.Controls.Add(this.TotalInvestmentLabel);
            this.SummaryGroupBox.Controls.Add(this.ExitSummaryButton);
            this.SummaryGroupBox.Controls.Add(this.HomePageButton2);
            this.SummaryGroupBox.Controls.Add(this.SummaryLabel7);
            this.SummaryGroupBox.Controls.Add(this.ResetButton);
            this.SummaryGroupBox.Controls.Add(this.SearchButton);
            this.SummaryGroupBox.Controls.Add(this.SearchKeyTextBox);
            this.SummaryGroupBox.Controls.Add(this.SummaryGrid);
            this.SummaryGroupBox.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.SummaryGroupBox.Location = new System.Drawing.Point(42, 82);
            this.SummaryGroupBox.Name = "SummaryGroupBox";
            this.SummaryGroupBox.Size = new System.Drawing.Size(893, 590);
            this.SummaryGroupBox.TabIndex = 23;
            this.SummaryGroupBox.TabStop = false;
            // 
            // ExitSummaryButton
            // 
            this.ExitSummaryButton.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ExitSummaryButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ExitSummaryButton.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ExitSummaryButton.Location = new System.Drawing.Point(742, 526);
            this.ExitSummaryButton.Name = "ExitSummaryButton";
            this.ExitSummaryButton.Size = new System.Drawing.Size(112, 37);
            this.ExitSummaryButton.TabIndex = 6;
            this.ExitSummaryButton.Text = "Exi&t ";
            this.ExitTooltip.SetToolTip(this.ExitSummaryButton, "Click to Exit Application");
            this.ExitSummaryButton.UseVisualStyleBackColor = false;
            this.ExitSummaryButton.Click += new System.EventHandler(this.ExitSummaryButton_Click);
            // 
            // HomePageButton2
            // 
            this.HomePageButton2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.HomePageButton2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.HomePageButton2.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HomePageButton2.Location = new System.Drawing.Point(34, 526);
            this.HomePageButton2.Name = "HomePageButton2";
            this.HomePageButton2.Size = new System.Drawing.Size(127, 37);
            this.HomePageButton2.TabIndex = 5;
            this.HomePageButton2.Text = "< H&ome Page";
            this.HomePageTooltip.SetToolTip(this.HomePageButton2, "Click to go to Home Page");
            this.HomePageButton2.UseVisualStyleBackColor = false;
            this.HomePageButton2.Click += new System.EventHandler(this.HomePageButton2_Click);
            // 
            // SummaryLabel7
            // 
            this.SummaryLabel7.AutoSize = true;
            this.SummaryLabel7.Font = new System.Drawing.Font("Times New Roman", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SummaryLabel7.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.SummaryLabel7.Location = new System.Drawing.Point(30, 47);
            this.SummaryLabel7.Name = "SummaryLabel7";
            this.SummaryLabel7.Size = new System.Drawing.Size(164, 19);
            this.SummaryLabel7.TabIndex = 4;
            this.SummaryLabel7.Text = "Investment Summary";
            // 
            // ResetButton
            // 
            this.ResetButton.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ResetButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ResetButton.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ResetButton.Location = new System.Drawing.Point(742, 90);
            this.ResetButton.Name = "ResetButton";
            this.ResetButton.Size = new System.Drawing.Size(112, 37);
            this.ResetButton.TabIndex = 3;
            this.ResetButton.Text = "&Reset";
            this.ResetTooltip.SetToolTip(this.ResetButton, "Click to Reset Search");
            this.ResetButton.UseVisualStyleBackColor = false;
            this.ResetButton.Click += new System.EventHandler(this.ResetButton_Click);
            // 
            // SearchButton
            // 
            this.SearchButton.BackColor = System.Drawing.SystemColors.ControlLight;
            this.SearchButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.SearchButton.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchButton.Location = new System.Drawing.Point(596, 90);
            this.SearchButton.Name = "SearchButton";
            this.SearchButton.Size = new System.Drawing.Size(112, 37);
            this.SearchButton.TabIndex = 2;
            this.SearchButton.Text = "&Search";
            this.SearchTooltip.SetToolTip(this.SearchButton, "Click to Search by Transaction_ID or Email");
            this.SearchButton.UseVisualStyleBackColor = false;
            this.SearchButton.Click += new System.EventHandler(this.SearchButton_Click);
            // 
            // SearchKeyTextBox
            // 
            this.SearchKeyTextBox.Location = new System.Drawing.Point(358, 96);
            this.SearchKeyTextBox.Name = "SearchKeyTextBox";
            this.SearchKeyTextBox.Size = new System.Drawing.Size(207, 27);
            this.SearchKeyTextBox.TabIndex = 1;
            // 
            // SummaryGrid
            // 
            this.SummaryGrid.AllowUserToAddRows = false;
            this.SummaryGrid.AllowUserToDeleteRows = false;
            this.SummaryGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader;
            this.SummaryGrid.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.SummaryGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.SummaryGrid.Location = new System.Drawing.Point(34, 160);
            this.SummaryGrid.Name = "SummaryGrid";
            this.SummaryGrid.ReadOnly = true;
            this.SummaryGrid.RowHeadersWidth = 51;
            this.SummaryGrid.RowTemplate.Height = 24;
            this.SummaryGrid.Size = new System.Drawing.Size(821, 204);
            this.SummaryGrid.TabIndex = 0;
            // 
            // SearchTooltip
            // 
            this.SearchTooltip.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            // 
            // ResetTooltip
            // 
            this.ResetTooltip.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            // 
            // HomePageTooltip
            // 
            this.HomePageTooltip.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Warning;
            // 
            // ExitTooltip
            // 
            this.ExitTooltip.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Warning;
            // 
            // TotalInvestmentLabel
            // 
            this.TotalInvestmentLabel.AutoSize = true;
            this.TotalInvestmentLabel.Font = new System.Drawing.Font("Times New Roman", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalInvestmentLabel.Location = new System.Drawing.Point(30, 460);
            this.TotalInvestmentLabel.Name = "TotalInvestmentLabel";
            this.TotalInvestmentLabel.Size = new System.Drawing.Size(131, 19);
            this.TotalInvestmentLabel.TabIndex = 7;
            this.TotalInvestmentLabel.Text = "Total Investment";
            // 
            // TotalTransactionTextBox
            // 
            this.TotalTransactionTextBox.Location = new System.Drawing.Point(196, 398);
            this.TotalTransactionTextBox.Name = "TotalTransactionTextBox";
            this.TotalTransactionTextBox.Size = new System.Drawing.Size(212, 27);
            this.TotalTransactionTextBox.TabIndex = 8;
            // 
            // TotalInterestLabel
            // 
            this.TotalInterestLabel.AutoSize = true;
            this.TotalInterestLabel.Font = new System.Drawing.Font("Times New Roman", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalInterestLabel.Location = new System.Drawing.Point(516, 401);
            this.TotalInterestLabel.Name = "TotalInterestLabel";
            this.TotalInterestLabel.Size = new System.Drawing.Size(108, 19);
            this.TotalInterestLabel.TabIndex = 9;
            this.TotalInterestLabel.Text = "Total Interest";
            // 
            // TotalInterestTextBox
            // 
            this.TotalInterestTextBox.Location = new System.Drawing.Point(644, 398);
            this.TotalInterestTextBox.Name = "TotalInterestTextBox";
            this.TotalInterestTextBox.Size = new System.Drawing.Size(211, 27);
            this.TotalInterestTextBox.TabIndex = 10;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(516, 455);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(110, 19);
            this.label7.TabIndex = 11;
            this.label7.Text = "Average Term";
            // 
            // AverageTermTextBox
            // 
            this.AverageTermTextBox.Location = new System.Drawing.Point(644, 452);
            this.AverageTermTextBox.Name = "AverageTermTextBox";
            this.AverageTermTextBox.Size = new System.Drawing.Size(210, 27);
            this.AverageTermTextBox.TabIndex = 12;
            // 
            // TotalInvestmentTextBox
            // 
            this.TotalInvestmentTextBox.Location = new System.Drawing.Point(196, 452);
            this.TotalInvestmentTextBox.Name = "TotalInvestmentTextBox";
            this.TotalInvestmentTextBox.Size = new System.Drawing.Size(212, 27);
            this.TotalInvestmentTextBox.TabIndex = 13;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(30, 401);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(144, 19);
            this.label8.TabIndex = 14;
            this.label8.Text = "Total Transactions";
            // 
            // DisplayToolTip
            // 
            this.DisplayToolTip.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            // 
            // EditSelectionTooltip
            // 
            this.EditSelectionTooltip.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            // 
            // ProceedTooltip
            // 
            this.ProceedTooltip.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            // 
            // ClearToolTip
            // 
            this.ClearToolTip.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            // 
            // ConfirmTooltip
            // 
            this.ConfirmTooltip.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            // 
            // InvestMeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BackgroundImage = global::InvestMe.Properties.Resources.InvestMeLogo;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(972, 743);
            this.Controls.Add(this.SummaryGroupBox);
            this.Controls.Add(this.InvestmentConfirmationGroupBox);
            this.Controls.Add(this.InvestmentGroupBox);
            this.Controls.Add(this.HomePageGroupBox);
            this.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.DarkGreen;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "InvestMeForm";
            this.Text = "InvestMe";
            this.HomePageGroupBox.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.LogoBox)).EndInit();
            this.InvestmentGroupBox.ResumeLayout(false);
            this.InvestmentGroupBox.PerformLayout();
            this.CustomerInfoGroupBox.ResumeLayout(false);
            this.CustomerInfoGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.InvestmentDetailsGrid)).EndInit();
            this.InvestmentConfirmationGroupBox.ResumeLayout(false);
            this.InvestmentConfirmationGroupBox.PerformLayout();
            this.SummaryGroupBox.ResumeLayout(false);
            this.SummaryGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SummaryGrid)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button NewInvestmentButton;
        private System.Windows.Forms.Button SummaryButton;
        private System.Windows.Forms.Button ExitButton;
        private System.Windows.Forms.GroupBox HomePageGroupBox;
        private System.Windows.Forms.GroupBox InvestmentGroupBox;
        private System.Windows.Forms.Button DisplayButton;
        private System.Windows.Forms.TextBox PrincipleInvestmentAmountTextBox;
        private System.Windows.Forms.Label InvestmentAmountLabel;
        private System.Windows.Forms.Button ProceedButton;
        private System.Windows.Forms.DataGridView InvestmentDetailsGrid;
        private System.Windows.Forms.GroupBox CustomerInfoGroupBox;
        private System.Windows.Forms.Label TelephoneNumberLabel;
        private System.Windows.Forms.Label CustomerNameLabel;
        private System.Windows.Forms.Button HomePageButton;
        private System.Windows.Forms.Button EditSelectionButton;
        private System.Windows.Forms.Button ExitButton2;
        private System.Windows.Forms.Button ConfirmPlanButton;
        private System.Windows.Forms.Button ClearButton;
        private System.Windows.Forms.TextBox TransactionIDTextBox;
        private System.Windows.Forms.TextBox EmailIDTextBox;
        private System.Windows.Forms.TextBox TelephoneNumberTextBox;
        private System.Windows.Forms.TextBox CustomerNameTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label EmailLabel;
        private System.Windows.Forms.GroupBox InvestmentConfirmationGroupBox;
        private System.Windows.Forms.Label TransactionIdLabel;
        private System.Windows.Forms.Label TransactionDetailsLabel;
        private System.Windows.Forms.Label ContactNumberLabel;
        private System.Windows.Forms.Label EmailIDLabel;
        private System.Windows.Forms.Label NameLabel;
        private System.Windows.Forms.Label CustomerInfoLabel;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label InvestedAmountLabel;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox ROIConfirmationTextBox;
        private System.Windows.Forms.TextBox InterestAmountConfirmationTextBox;
        private System.Windows.Forms.TextBox InterestRateConfirmationTextBox;
        private System.Windows.Forms.TextBox InvestmentTermConfirmationTextBox;
        private System.Windows.Forms.TextBox InvestmentAmountConfirmationTextBox;
        private System.Windows.Forms.TextBox TransactionIDConfirmationTextBox;
        private System.Windows.Forms.TextBox ContactNumberConfirmationTextBox;
        private System.Windows.Forms.TextBox EmailIDConfirmationTextBox;
        private System.Windows.Forms.TextBox NameConfirmationTextBox;
        private System.Windows.Forms.Button EditInvestmentButton;
        private System.Windows.Forms.Button ConfirmInvestmentButton;
        private System.Windows.Forms.GroupBox SummaryGroupBox;
        private System.Windows.Forms.DataGridView SummaryGrid;
        private System.Windows.Forms.Button ResetButton;
        private System.Windows.Forms.Button SearchButton;
        private System.Windows.Forms.TextBox SearchKeyTextBox;
        private System.Windows.Forms.PictureBox LogoBox;
        private System.Windows.Forms.Button ExitSummaryButton;
        private System.Windows.Forms.Button HomePageButton2;
        private System.Windows.Forms.Label SummaryLabel7;
        private System.Windows.Forms.ToolTip ExitTooltip;
        private System.Windows.Forms.ToolTip HomePageTooltip;
        private System.Windows.Forms.ToolTip ResetTooltip;
        private System.Windows.Forms.ToolTip SearchTooltip;
        private System.Windows.Forms.TextBox TotalInterestTextBox;
        private System.Windows.Forms.Label TotalInterestLabel;
        private System.Windows.Forms.TextBox TotalTransactionTextBox;
        private System.Windows.Forms.Label TotalInvestmentLabel;
        private System.Windows.Forms.TextBox AverageTermTextBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox TotalInvestmentTextBox;
        private System.Windows.Forms.ToolTip EditSelectionTooltip;
        private System.Windows.Forms.ToolTip ClearToolTip;
        private System.Windows.Forms.ToolTip ProceedTooltip;
        private System.Windows.Forms.ToolTip DisplayToolTip;
        private System.Windows.Forms.ToolTip ConfirmTooltip;
    }
}

